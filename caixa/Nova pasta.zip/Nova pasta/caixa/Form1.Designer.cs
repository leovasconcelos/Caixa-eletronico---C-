﻿namespace caixa
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcular = new System.Windows.Forms.Button();
            this.cbMa = new System.Windows.Forms.CheckBox();
            this.cbME = new System.Windows.Forms.CheckBox();
            this.txtD = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtMa500 = new System.Windows.Forms.TextBox();
            this.txtMa100 = new System.Windows.Forms.TextBox();
            this.txtMa40 = new System.Windows.Forms.TextBox();
            this.txtMa4 = new System.Windows.Forms.TextBox();
            this.txtMa3 = new System.Windows.Forms.TextBox();
            this.txtMa25 = new System.Windows.Forms.TextBox();
            this.txtMa5 = new System.Windows.Forms.TextBox();
            this.txtMa10 = new System.Windows.Forms.TextBox();
            this.btnLbaixo = new System.Windows.Forms.Button();
            this.btnLcima = new System.Windows.Forms.Button();
            this.txtMe500 = new System.Windows.Forms.TextBox();
            this.txtMe40 = new System.Windows.Forms.TextBox();
            this.txtMe25 = new System.Windows.Forms.TextBox();
            this.txtMe100 = new System.Windows.Forms.TextBox();
            this.txtMe5 = new System.Windows.Forms.TextBox();
            this.txtMe10 = new System.Windows.Forms.TextBox();
            this.txtMe4 = new System.Windows.Forms.TextBox();
            this.txtMe3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lblTrocoMenor = new System.Windows.Forms.Label();
            this.lblTrocoMaior = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(159, 112);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 22);
            this.btnCalcular.TabIndex = 0;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // cbMa
            // 
            this.cbMa.AutoSize = true;
            this.cbMa.Location = new System.Drawing.Point(283, 172);
            this.cbMa.Name = "cbMa";
            this.cbMa.Size = new System.Drawing.Size(154, 17);
            this.cbMa.TabIndex = 1;
            this.cbMa.Text = "Maior Quantidade de notas";
            this.cbMa.UseVisualStyleBackColor = true;
            // 
            // cbME
            // 
            this.cbME.AutoSize = true;
            this.cbME.Location = new System.Drawing.Point(18, 172);
            this.cbME.Name = "cbME";
            this.cbME.Size = new System.Drawing.Size(158, 17);
            this.cbME.TabIndex = 2;
            this.cbME.Text = "Menor Quantidade de notas";
            this.cbME.UseVisualStyleBackColor = true;
            // 
            // txtD
            // 
            this.txtD.Location = new System.Drawing.Point(259, 55);
            this.txtD.Name = "txtD";
            this.txtD.Size = new System.Drawing.Size(100, 20);
            this.txtD.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(130, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Quant. de dinheiro";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(68, 221);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "500";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(68, 248);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "100";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(68, 272);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(19, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "40";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(157, 221);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(19, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "25";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(157, 248);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(19, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "10";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(110, 309);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(13, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "4";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(157, 272);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(13, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "5";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(111, 336);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(13, 13);
            this.label13.TabIndex = 4;
            this.label13.Text = "3";
            // 
            // txtMa500
            // 
            this.txtMa500.Enabled = false;
            this.txtMa500.Location = new System.Drawing.Point(12, 218);
            this.txtMa500.Name = "txtMa500";
            this.txtMa500.Size = new System.Drawing.Size(43, 20);
            this.txtMa500.TabIndex = 3;
            // 
            // txtMa100
            // 
            this.txtMa100.Enabled = false;
            this.txtMa100.Location = new System.Drawing.Point(12, 245);
            this.txtMa100.Name = "txtMa100";
            this.txtMa100.Size = new System.Drawing.Size(43, 20);
            this.txtMa100.TabIndex = 3;
            // 
            // txtMa40
            // 
            this.txtMa40.Enabled = false;
            this.txtMa40.Location = new System.Drawing.Point(12, 269);
            this.txtMa40.Name = "txtMa40";
            this.txtMa40.Size = new System.Drawing.Size(43, 20);
            this.txtMa40.TabIndex = 3;
            // 
            // txtMa4
            // 
            this.txtMa4.Enabled = false;
            this.txtMa4.Location = new System.Drawing.Point(61, 306);
            this.txtMa4.Name = "txtMa4";
            this.txtMa4.Size = new System.Drawing.Size(43, 20);
            this.txtMa4.TabIndex = 3;
            // 
            // txtMa3
            // 
            this.txtMa3.Enabled = false;
            this.txtMa3.Location = new System.Drawing.Point(61, 333);
            this.txtMa3.Name = "txtMa3";
            this.txtMa3.Size = new System.Drawing.Size(43, 20);
            this.txtMa3.TabIndex = 3;
            // 
            // txtMa25
            // 
            this.txtMa25.Enabled = false;
            this.txtMa25.Location = new System.Drawing.Point(108, 218);
            this.txtMa25.Name = "txtMa25";
            this.txtMa25.Size = new System.Drawing.Size(43, 20);
            this.txtMa25.TabIndex = 3;
            // 
            // txtMa5
            // 
            this.txtMa5.Enabled = false;
            this.txtMa5.Location = new System.Drawing.Point(108, 269);
            this.txtMa5.Name = "txtMa5";
            this.txtMa5.Size = new System.Drawing.Size(43, 20);
            this.txtMa5.TabIndex = 3;
            // 
            // txtMa10
            // 
            this.txtMa10.Enabled = false;
            this.txtMa10.Location = new System.Drawing.Point(108, 245);
            this.txtMa10.Name = "txtMa10";
            this.txtMa10.Size = new System.Drawing.Size(43, 20);
            this.txtMa10.TabIndex = 3;
            // 
            // btnLbaixo
            // 
            this.btnLbaixo.Location = new System.Drawing.Point(259, 112);
            this.btnLbaixo.Name = "btnLbaixo";
            this.btnLbaixo.Size = new System.Drawing.Size(75, 22);
            this.btnLbaixo.TabIndex = 5;
            this.btnLbaixo.Text = "Limpar";
            this.btnLbaixo.UseVisualStyleBackColor = true;
            this.btnLbaixo.Click += new System.EventHandler(this.btnLbaixo_Click);
            // 
            // btnLcima
            // 
            this.btnLcima.Location = new System.Drawing.Point(365, 50);
            this.btnLcima.Name = "btnLcima";
            this.btnLcima.Size = new System.Drawing.Size(57, 28);
            this.btnLcima.TabIndex = 5;
            this.btnLcima.Text = "Limpar";
            this.btnLcima.UseVisualStyleBackColor = true;
            this.btnLcima.Click += new System.EventHandler(this.btnLcima_Click);
            // 
            // txtMe500
            // 
            this.txtMe500.Enabled = false;
            this.txtMe500.Location = new System.Drawing.Point(283, 214);
            this.txtMe500.Name = "txtMe500";
            this.txtMe500.Size = new System.Drawing.Size(43, 20);
            this.txtMe500.TabIndex = 3;
            // 
            // txtMe40
            // 
            this.txtMe40.Enabled = false;
            this.txtMe40.Location = new System.Drawing.Point(283, 265);
            this.txtMe40.Name = "txtMe40";
            this.txtMe40.Size = new System.Drawing.Size(43, 20);
            this.txtMe40.TabIndex = 3;
            // 
            // txtMe25
            // 
            this.txtMe25.Enabled = false;
            this.txtMe25.Location = new System.Drawing.Point(379, 214);
            this.txtMe25.Name = "txtMe25";
            this.txtMe25.Size = new System.Drawing.Size(43, 20);
            this.txtMe25.TabIndex = 3;
            // 
            // txtMe100
            // 
            this.txtMe100.Enabled = false;
            this.txtMe100.Location = new System.Drawing.Point(283, 241);
            this.txtMe100.Name = "txtMe100";
            this.txtMe100.Size = new System.Drawing.Size(43, 20);
            this.txtMe100.TabIndex = 3;
            // 
            // txtMe5
            // 
            this.txtMe5.Enabled = false;
            this.txtMe5.Location = new System.Drawing.Point(379, 265);
            this.txtMe5.Name = "txtMe5";
            this.txtMe5.Size = new System.Drawing.Size(43, 20);
            this.txtMe5.TabIndex = 3;
            // 
            // txtMe10
            // 
            this.txtMe10.Enabled = false;
            this.txtMe10.Location = new System.Drawing.Point(379, 241);
            this.txtMe10.Name = "txtMe10";
            this.txtMe10.Size = new System.Drawing.Size(43, 20);
            this.txtMe10.TabIndex = 3;
            // 
            // txtMe4
            // 
            this.txtMe4.Enabled = false;
            this.txtMe4.Location = new System.Drawing.Point(332, 302);
            this.txtMe4.Name = "txtMe4";
            this.txtMe4.Size = new System.Drawing.Size(43, 20);
            this.txtMe4.TabIndex = 3;
            // 
            // txtMe3
            // 
            this.txtMe3.Enabled = false;
            this.txtMe3.Location = new System.Drawing.Point(332, 329);
            this.txtMe3.Name = "txtMe3";
            this.txtMe3.Size = new System.Drawing.Size(43, 20);
            this.txtMe3.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(339, 217);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "500";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(428, 244);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(19, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "10";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(339, 268);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(19, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "40";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(339, 244);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(25, 13);
            this.label12.TabIndex = 4;
            this.label12.Text = "100";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(381, 305);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(13, 13);
            this.label14.TabIndex = 4;
            this.label14.Text = "4";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(428, 268);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(13, 13);
            this.label15.TabIndex = 4;
            this.label15.Text = "5";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(428, 217);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(19, 13);
            this.label16.TabIndex = 4;
            this.label16.Text = "25";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(382, 332);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(13, 13);
            this.label17.TabIndex = 4;
            this.label17.Text = "3";
            // 
            // lblTrocoMenor
            // 
            this.lblTrocoMenor.AutoSize = true;
            this.lblTrocoMenor.Location = new System.Drawing.Point(71, 382);
            this.lblTrocoMenor.Name = "lblTrocoMenor";
            this.lblTrocoMenor.Size = new System.Drawing.Size(22, 13);
            this.lblTrocoMenor.TabIndex = 6;
            this.lblTrocoMenor.Text = ". . .";
            // 
            // lblTrocoMaior
            // 
            this.lblTrocoMaior.AutoSize = true;
            this.lblTrocoMaior.Location = new System.Drawing.Point(342, 382);
            this.lblTrocoMaior.Name = "lblTrocoMaior";
            this.lblTrocoMaior.Size = new System.Drawing.Size(22, 13);
            this.lblTrocoMaior.TabIndex = 6;
            this.lblTrocoMaior.Text = ". . .";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(168, 382);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(104, 13);
            this.label18.TabIndex = 7;
            this.label18.Text = "Não tenhos nota de:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 421);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.lblTrocoMaior);
            this.Controls.Add(this.lblTrocoMenor);
            this.Controls.Add(this.btnLcima);
            this.Controls.Add(this.btnLbaixo);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtMe3);
            this.Controls.Add(this.txtMa3);
            this.Controls.Add(this.txtMe4);
            this.Controls.Add(this.txtMa4);
            this.Controls.Add(this.txtMe10);
            this.Controls.Add(this.txtMa10);
            this.Controls.Add(this.txtMe5);
            this.Controls.Add(this.txtMe100);
            this.Controls.Add(this.txtMa5);
            this.Controls.Add(this.txtMe25);
            this.Controls.Add(this.txtMa100);
            this.Controls.Add(this.txtMe40);
            this.Controls.Add(this.txtMa25);
            this.Controls.Add(this.txtMe500);
            this.Controls.Add(this.txtMa40);
            this.Controls.Add(this.txtMa500);
            this.Controls.Add(this.txtD);
            this.Controls.Add(this.cbME);
            this.Controls.Add(this.cbMa);
            this.Controls.Add(this.btnCalcular);
            this.Name = "Form1";
            this.Text = "caixa";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.CheckBox cbMa;
        private System.Windows.Forms.CheckBox cbME;
        private System.Windows.Forms.TextBox txtD;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtMa500;
        private System.Windows.Forms.TextBox txtMa100;
        private System.Windows.Forms.TextBox txtMa40;
        private System.Windows.Forms.TextBox txtMa4;
        private System.Windows.Forms.TextBox txtMa3;
        private System.Windows.Forms.TextBox txtMa25;
        private System.Windows.Forms.TextBox txtMa5;
        private System.Windows.Forms.TextBox txtMa10;
        private System.Windows.Forms.Button btnLbaixo;
        private System.Windows.Forms.Button btnLcima;
        private System.Windows.Forms.TextBox txtMe500;
        private System.Windows.Forms.TextBox txtMe40;
        private System.Windows.Forms.TextBox txtMe25;
        private System.Windows.Forms.TextBox txtMe100;
        private System.Windows.Forms.TextBox txtMe5;
        private System.Windows.Forms.TextBox txtMe10;
        private System.Windows.Forms.TextBox txtMe4;
        private System.Windows.Forms.TextBox txtMe3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblTrocoMenor;
        private System.Windows.Forms.Label lblTrocoMaior;
        private System.Windows.Forms.Label label18;
    }
}

